==========================================================
Docker Container Instructions for Telerobotics
==========================================================

:Author: Siddhant Shrivastava

.. contents::
   :local:
   :depth: 2

Change Record
=============

.. If the changelog is saved on an external file (e.g. in servers/sname/NEWS),
   it can be included here by using (dedent to make it work):

25\ :sup:`th`\  May, 2015 - Document created.

  .. literalinclude:: ../../servers/servername/NEWS


Introduction
============



    ``docker run --net=host -i -t sidcode/ros-eras bash ``
