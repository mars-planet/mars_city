==========================================================================
Setting up and Callibrating the Minoru 3D Camera
==========================================================================

:Author: Siddhant Shrivastava

Change Record
=============

20\ :sup:`th`\  July, 2015 - Document Created
